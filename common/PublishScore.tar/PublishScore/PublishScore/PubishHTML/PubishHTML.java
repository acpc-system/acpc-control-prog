/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.jsoup.Jsoup;

/**
 * 
 * @author Ibraheem Halloum
 */
public class PubishHTML {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) throws InterruptedException {

		// String server = "acpc.global";
		final String server = "acpc.global";
		final int port = 21;
		final String user = "scoreboards@acpc.global";
		//final String pass = "291g9!7{!+5A";
		final String pass = "_3{q7m+bDggj";

		// ftpClient;

		try {

			while (true) {
				try {
					new Thread(new Runnable() {

						public void run() {
							FTPClient ftpClient=null;
							try {
								ftpClient = new FTPClient();
								ftpClient.connect(server, port);
								ftpClient.login(user, pass);
								ftpClient.enterLocalPassiveMode();

								ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
								// String html =
								// Jsoup.connect("http://41.178.191.100/sfaxcpc2017/css/style.css").get().html();
								String html = Jsoup
										.connect("http://web/scoreboard/")
										.get().html();
								PrintWriter out = new PrintWriter(
								   		"./index.html");
								out.print(html);
								out.close();
								File firstLocalFile = new File("./index.html");
								String firstRemoteFile = "./pcpc2018/index.html";
								InputStream inputStream = new FileInputStream(
										firstLocalFile);

								System.out.println("Start uploading Score");
								boolean done = ftpClient.storeFile(
										firstRemoteFile, inputStream);
								inputStream.close();

								if (done) {
									DateFormat dateFormat = new SimpleDateFormat(
											"yyyy/MM/dd HH:mm:ss");
									// get current date time with Date()
									Date date = new Date();
									System.out.println(dateFormat.format(date));
									System.out
											.println("The first file is uploaded successfully.");
									System.out
											.println("----------------------------------------");
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							finally{
								try {
									ftpClient.disconnect();
								} catch (IOException e) {
									
									e.printStackTrace();
								}
							}
						}
					}).start();
					Thread.sleep(60 * 1000);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
