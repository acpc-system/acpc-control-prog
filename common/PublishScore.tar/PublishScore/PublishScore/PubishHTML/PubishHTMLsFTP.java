
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jsoup.Jsoup;
import com.jcraft.jsch.*;

/**
 * 
 * @author Ibraheem Halloum
 */
public class PubishHTMLsFTP {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) throws InterruptedException {

		// String server = "acpc.global";
		final String server = "172.20.61.30";
		final int port = 22;
		final String user = "acmsite";
		// final String pass = "291g9!7{!+5A";
		final String pass = "@cm$itebr_4#64";

		// ftpClient;

		try {

			while (true) {
				try {
					new Thread(new Runnable() {

						public void run() {

							JSch jsch = new JSch();
							Session session = null;
							try {
								session = jsch.getSession(user, server, port);
								session.setConfig("StrictHostKeyChecking", "no");
								session.setPassword(pass);
								session.connect();

								Channel channel = session.openChannel("sftp");
								channel.connect();
								ChannelSftp ChannelSftp = (ChannelSftp) channel;

							
								String html = Jsoup.connect("http://web.acmtcpc.tn/scoreboard/").get().html();
								PrintWriter out = new PrintWriter("./index.html");
								out.print(html);
								out.close();
								File firstLocalFile = new File("./index.html");
								String firstRemoteFile = "./scoreboards/TEKCPC2018/index.html";
								InputStream inputStream = new FileInputStream(firstLocalFile);

								System.out.println("Start uploading Score");
								ChannelSftp.put(inputStream,firstRemoteFile,0);
								
								inputStream.close();

								{
									DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
									// get current date time with Date()
									Date date = new Date();
									System.out.println(dateFormat.format(date));
									System.out.println("The first file is uploaded successfully.");
									System.out.println("----------------------------------------");
								}
								ChannelSftp.exit();
								session.disconnect();
							} catch (Exception e) {
								e.printStackTrace();
							} finally {
								try {
									
									session.disconnect();
								} catch (Exception e) {

									e.printStackTrace();
								}
							}
						}
					}).start();
					Thread.sleep(60 * 1000);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
